/*
	Name header
*/

#include "AnyList.h"

// Definition function getMin


// Definition function haveThree


// Definition function preFour
